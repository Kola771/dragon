

<footer>
    <div class="flex">
        <section>
            <h3>Actualités</h3>
        </section>
        <section>
            <h3>Les oeuvres les plus suivies</h3>
        </section>
        <section>
            <h3>Inédits</h3>
        </section>
    </div>
    <p>&copy;Copyright 2023</p>
</footer>
</body>
</html>