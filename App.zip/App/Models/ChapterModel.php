<?php

/**
 * class CommentModel pour faire toutes les requêtes liées à la table commments de la bd
 */
class ChapterModel extends Connexion {

    public $number;
    public $name;
    public $image;
    public $text;
    public $book_id;
    public $created_at;

    
    /**
     * verify(), pour vérifier si il y a un chapitre portant ce nom
     */
    public function verify($name) {
        $this->name = $name;

        $conn = $this->connect();

        /**
         * $sql, pour les requêtes vers la base de données
         */
        $sql = "SELECT * FROM `freek`.chapters WHERE chapter_title = ?;";

        /**
         * $stmt, pour recupérer la requête préparée
         */
        $stmt = $conn->prepare($sql);
        $stmt->execute([$this->name]);
        $result = $stmt->fetchAll();
        return $result;
    }

    
    /**
     * 
     */
    public function verifyNum($number) {
        $this->number = $number;

        $conn = $this->connect();

        /**
         * $sql, pour les requêtes vers la base de données
         */
        $sql = "SELECT * FROM `freek`.chapters WHERE chapter_number = ?;";

        /**
         * $stmt, pour recupérer la requête préparée
         */
        $stmt = $conn->prepare($sql);
        $stmt->execute([$this->number]);
        $result = $stmt->fetchAll();
        return $result;
    }

    public function insertChapter($number, $name, $image, $text, $book_id, $created_at) {
        
        $conn = $this->connect();
  
        $this->number = $number;
        $this->name = $name;
        $this->image = $image;
        $this->text = $text;
        $this->book_id = $book_id;
        $this->created_at = $created_at;
  
        /**
         * $sql, pour les requêtes vers la base de données
         */
        $sql = "INSERT INTO `freek`.chapters VALUES(NULL, :number, :name, :image, :text, :book_id, :created_at)";
        
        /**
         * $stmt, pour recupérer la requête préparée
         */
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ":number" => $this->number,
            ":name" => $this->name,
            ":image" => $this->image,
            ":text" => $this->text,
            ":book_id" => $this->book_id,
            ":created_at" => $this->created_at
        ]);
      }
  


}