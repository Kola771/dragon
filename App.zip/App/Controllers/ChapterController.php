
<?php
require "../App/Controllers/Connexion.php";
require "../App/Models/ChapterModel.php";

class ChapterController {

    /**
     * $chaptermodel; on va utiliser cette variable pour instancier la classe ChapterModel dans le controller
     */
    public $chaptermodel;

    //déclaration des variables
    public $number;
    public $name;
    public $image;
    public $text;
    public $book_id;
    public $created_at;

      
    /**
     * sanitaze(); pour les espacements et les injections de codes
     */
    public function sanitaze($data) {
        $reg = trim($data);
        $reg = htmlspecialchars($reg);
        $reg = stripslashes($reg);
        $data = $reg;
        return $data;
    }
    
    /**
     * emptyInputs(), pour vérifiez si un des champs est vide
     */
    public function emptyInputs() {

        if(empty($this->number) || empty($this->name) || empty($this->text)){
            header("Location:/admin/receive/create-chapter?msg_empty");
            exit();
        } 
            else{
            return false;
        }
    }

    public function addChapter() {
        if($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["validate"])) {

        $this->number = $this->sanitaze($_POST["number"]);
        $this->name = $this->sanitaze($_POST["name"]);
        $this->book_id = $this->sanitaze($_POST["name_mangas"]);

        $this->file_name = $_FILES["file"]["name"];
        $this->file_tmpname = $_FILES["file"]["tmp_name"];
        $this->file_error = $_FILES["file"]["error"];
        $this->file_size = $_FILES["file"]["size"];

        $this->text = $this->sanitaze($_POST["description"]);
        $this->text = nl2br($this->text);
        $this->created_at = date("Y-m-d h:i:s");
        $this->emptyInputs();

        $this->chaptermodel = new ChapterModel();
        $array = $this->chaptermodel->verify($this->name);
        $lenght = count($array);
        $count = count($this->file_name);

        
        if($lenght>0) {
            echo "Existe";
                exit;
            } 
            else {
                $array = $this->chaptermodel->verifyNum($this->number);
                
                $lenght = count($array);
                
                if($lenght>0) {
                    if($array[0]["book_id"] == $this->book_id) {
                        echo "Existe";
                        exit;
                    } 
                    else {
                        for($i=0; $i<$count; $i++) {
                            //récupération de l'extension de l'image
                            $tabExtension = pathinfo($this->file_name[$i], PATHINFO_EXTENSION);
                            $extension = strtolower($tabExtension);
                            $extensions = ['jpg', 'png', 'jpeg', 'gif'];
                            $maxSize = 4000000;
                            if(in_array($extension, $extensions)) {
                                if($this->file_size[$i] <= $maxSize) {
                                    if($this->file_error[$i] == 0) {
                
                                        $uniqueName = uniqid('mangas-image-', true);
                                        // uniqid génère quelque chose comme ca : mangas-63b85c9a42aac7.70071232
                
                                        $file = $uniqueName.".".$extension;
                                        move_uploaded_file($this->file_tmpname[$i], '../public/ressources/assets/medias-chapters/medias-mangas/'.$file);
                                        
                                        $this->number = $this->number +1;
                                        $this->chaptermodel->insertChapter($this->number, $this->name, $file, $this->text, $this->book_id, $this->created_at);
        
                                        echo "Enrégistrée";
                
                                    } else {
                                        echo "Images non téléchargées";
                                        exit();
                                    }
                
                                } else{
                                    echo "Taille élevée";
                                    exit();
                                }
                            } else {
                                echo "Mauvaise extension";
                                exit();
                            }
                        }
                    }
                } 
                else { 
                    
                for($i=0; $i<$count; $i++) {
                    //récupération de l'extension de l'image
                    $tabExtension = pathinfo($this->file_name[$i], PATHINFO_EXTENSION);
                    $extension = strtolower($tabExtension);
                    $extensions = ['jpg', 'png', 'jpeg', 'gif'];
                    $maxSize = 4000000;
                    if(in_array($extension, $extensions)) {
                        if($this->file_size[$i] <= $maxSize) {
                            if($this->file_error[$i] == 0) {
        
                                $uniqueName = uniqid('mangas-image-', true);
                                // uniqid génère quelque chose comme ca : mangas-63b85c9a42aac7.70071232
        
                                $file = $uniqueName.".".$extension;
                                move_uploaded_file($this->file_tmpname[$i], '../public/ressources/assets/medias-chapters/medias-mangas/'.$file);

                                $this->chaptermodel->insertChapter($this->number, $this->name, $file, $this->text, $this->book_id, $this->created_at);

                                echo "Enrégistrée";
        
                            } else {
                                echo "Images non téléchargées";
                                exit();
                            }
        
                        } else{
                            echo "Taille élevée";
                            exit();
                        }
                    } else {
                        echo "Mauvaise extension";
                        exit();
                    }
                }
            }
            }

        }
    }

}